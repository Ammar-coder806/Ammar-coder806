Hello 
This project is creted by Ammar 
there some steps you should follow to open the website 

1.first open project in a code editor i recomend vs code
2.install exstention in that Named Live Server 
3.then click go live button on cde editor to see webpage